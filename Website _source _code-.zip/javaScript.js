


$(document).ready(function(){
window.addEventListener('scroll',()=>{
    document.querySelector('nav').classList.toggle('window-scroll',window.scrollY>0)
})

const textpara=document.querySelectorAll('.contact_circle');

textpara.forEach(textpara1=> {

    let paraelements=textpara1.querySelector('p');
    
    paraelements.innerHTML=paraelements.innerHTML.split('').map((Character,index) => `<span style="transform:rotate(${index * 12}deg)
    ">${Character}</span>`).join('')
    
});

var swiper = new Swiper(".mySwiper", {
    slidesPerView: 3,
    spaceBetween: 30,
    freeMode: true,
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    breakpoints:{
      599:{
        slidesPerView:2,
        spaceBetween:40
      },
      1023 :{
        slidesPerView:3,
        spaceBetween:60
      }
    }
  });


//NavBar//
const open=document.querySelector('#nav_toggle_open');
const close=document.querySelector('#nav_toggle_close');
const nav_links=document.querySelector('.nav_links');

open.addEventListener('click',()=>{
  nav_links.style.display='block';
  open.style.display="none";
  close.style.display="inline-block";
})

const closeNav = () =>{
  nav_links.style.display="none";
  open.style.display="inline-block";
  close.style.display="none";
}

close.addEventListener('click',closeNav);

nav_links.querySelector('li a').forEach(navlinks=>{
  navlinks.addEventListener('click',closeNav);
})


})