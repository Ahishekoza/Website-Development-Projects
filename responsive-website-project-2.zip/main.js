

window.onload=function digital(){
    let toggle=document.querySelector('#nav .toggle-btn');
    let collapse=document.querySelector('#nav .collapse');

    toggle.addEventListener('click',function(event){
        collapse.classList.toggle('active')
    })

    let grid=document.querySelector("#recent-work-area .images-flex")

    let msnry=new Masonry(grid,{
        itemSelector:'.flex-item',
        gutter:100,
        fitWidth:true
    })
    
    // $('.images-flex').masonry({
    //     // options
    //     itemSelector: '.flex-item',
    //     fitWidth:true,
    //     gutter:100
    //   });
   
}
var rellax=new Rellax('.rellax',{
    center:true
})